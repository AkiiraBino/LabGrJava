import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000,800, 1); 
        GreenfootImage img = new GreenfootImage(1000,800);
        img.setColor(Color.BLACK);
        img.fill();
        img.setColor(new Color(120, 72, 0));
        img.fillRect(0, 740, 1000, 60);
        img.setColor(new Color(121, 204, 25));
        img.fillRect(0, 740, 1000, 25);
        img.setColor(Color.WHITE);
        for(int i=0;i<15;i++)img.fillOval(Greenfoot.getRandomNumber(1000), Greenfoot.getRandomNumber(600), 10, 10);
        setBackground(img);
        setPaintOrder(Firework.class, Shard.class, Trail.class);
    }
    public void act()
    {
        if(Greenfoot.getRandomNumber(1000)<40)
        addObject(new Firework(), Greenfoot.getRandomNumber(1000), 800);
    }
}
